CONFIGS_DIR= "work_files/configs/"
DEVICES="work_files/inventory.csv"
TEMPLATE="work_files/templates/config_template.jnj"