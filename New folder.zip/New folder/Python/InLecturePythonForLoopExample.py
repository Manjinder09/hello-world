device = ['r1', 'r2', 'r3']
for blah in device:
     print "blah can be any word.  Device is {}".format(blah)