#APIC="sandboxapic.cisco.com:9443"
APIC="sandboxapic.cisco.com"
APIC_USER="devnetuser"
APIC_PASSWORD="Cisco123!"
